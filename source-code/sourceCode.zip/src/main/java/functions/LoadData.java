package functions;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.Channels;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;

import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.FormatOptions;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobException;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobStatistics.LoadStatistics;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.TableDataWriteChannel;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.WriteChannelConfiguration;
import com.google.cloud.functions.BackgroundFunction;
import com.google.cloud.functions.Context;

import functions.eventpojos.GcsEvent;
import functions.utils.Constants;

public class LoadData implements BackgroundFunction<GcsEvent> {
	private static final Logger logger = Logger.getLogger(LoadData.class.getName());

	private BigQuery bigquery = null;

	@Override
	public void accept(GcsEvent event, Context context) {
		logger.info("Event: " + context.eventId());
		logger.info("Event Type: " + context.eventType());
		logger.info("Bucket: " + event.getBucket());
		logger.info("File: " + event.getName());
		logger.info("Metageneration: " + event.getMetageneration());
		logger.info("Created: " + event.getTimeCreated());
		logger.info("Updated: " + event.getUpdated());
		StringBuilder sb = new StringBuilder("gs://" + event.getBucket() + "/" + event.getName());
		// si se carga el archivo de configuracion
		if (event.getName().substring(0, 3).equals(Constants.FILE_CONFIG_TXT)) {
			// se llena/sobreescribe la tabla de relacion rel_file_table
			try {
				writeFileToTable(Constants.BQ_DATASET_NAME, Constants.BQ_TABLE_CONFIG, new File(sb.toString()).toPath(),
						Constants.LOCATION);
			} catch (IOException | InterruptedException | TimeoutException e) {
				logger.info(e.getMessage());
			}
		} else if (event.getName().substring(0, 3).equals(Constants.PREFIJO)) {
			// si ha llegado un archivo de transferencia, se procede a la carga
			// inicializamos bigQueryService
			bigquery = BigQueryOptions.getDefaultInstance().getService();
			String nameFile = getNameFileWithOutDate(event.getName());
			String tableName = getTableNameByConfigFileName(nameFile);
			try {
				writeFileToTable(Constants.BQ_DATASET_NAME, tableName, new File(sb.toString()).toPath(),
						Constants.LOCATION);
			} catch (IOException | InterruptedException | TimeoutException e) {
				logger.info(e.getMessage());
			}
		}

	}

	/**
	 * Getting a tableName by config fileName.
	 */
	// [VARIABLE "fileName"]
	public String getTableNameByConfigFileName(String fileName) {
		String query = "SELECT table_name FROM `" + Constants.PROJECT + "." + Constants.BQ_DATASET_NAME
				+ ".rel_file_table` where file_to_upload='" + fileName + "';";
		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query).build();
		// Print the results.
		String tableName = null;
		try {
			for (FieldValueList row : bigquery.query(queryConfig).iterateAll()) {
				if (row.size() > 0) {
					tableName = row.get(0).toString();
				}
			}
		} catch (JobException | InterruptedException e) {
			logger.info("Error al recuperar el nombre de la tabla por archivo");
			e.printStackTrace();
		}
		logger.info(tableName);
		return tableName;
	}

	/**
	 * Example of writing a local file to a table.
	 */
	// [TARGET writer(WriteChannelConfiguration)]
	// [VARIABLE "my_dataset_name"]
	// [VARIABLE "my_table_name"]
	// [VARIABLE FileSystems.getDefault().getPath(".", "my-data.csv")]
	// [VARIABLE "us"]
	public long writeFileToTable(String datasetName, String tableName, Path csvPath,
			String location) throws IOException, InterruptedException, TimeoutException {
		// [START bigquery_load_from_file]
		TableId tableId = TableId.of(datasetName, tableName);
		WriteChannelConfiguration writeChannelConfiguration = WriteChannelConfiguration
				.newBuilder(tableId).setFormatOptions(FormatOptions.csv()).build();
		// The location must be specified; other fields can be auto-detected.
		JobId jobId = JobId.newBuilder().setLocation(location).build();
		TableDataWriteChannel writer = bigquery.writer(jobId, writeChannelConfiguration);
		// Write data to writer
		try (OutputStream stream = Channels.newOutputStream(writer)) {
			Files.copy(csvPath, stream);
		}
		// Get load job
		Job job = writer.getJob();
		job = job.waitFor();
		LoadStatistics stats = job.getStatistics();
		return stats.getOutputRows();
		// [END bigquery_load_from_file]
	}
	
	/**
	 * get newFileName
	 * in EJEMPLO_FILE_YYYYMMDD.txt
	 * out  EJEMPLO_FILE.txt
	 */
	private String getNameFileWithOutDate(String nombreFile) {
        String ext = nombreFile.substring(nombreFile.lastIndexOf("."),nombreFile.length());
		String newNameFile =nombreFile.substring(0,nombreFile.lastIndexOf("_")).concat(ext);
		return newNameFile;
	}

}
