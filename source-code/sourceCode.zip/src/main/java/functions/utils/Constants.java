package functions.utils;

import java.io.Serializable;

public class Constants implements Serializable {

	private static final long	serialVersionUID	= -6459898853338863589L;
	public static final String	PROJECT		= "gcp-terraform-init";
	public static final String	LOCATION		= "US";
	public static final String	PREFIJO				= "LPMX";
	public static final String	FILE_CONFIG_TXT		= "config-tables-file.txt";
	public static final String	BQ_DATASET_NAME			= "gcp_schema_bigquery";
	public static final String	BQ_TABLE_CONFIG		= "rel_file_table";
	

}
